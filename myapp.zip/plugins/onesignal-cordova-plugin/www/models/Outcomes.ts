export interface OutcomeEvent {
    session         : string;
    id              : string;
    timestamp       : number;
    weight          : number;
    notification_ids: string[];
}
